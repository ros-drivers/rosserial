/*******************************************************************************
* File Name: A1.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_A1_H) /* Pins A1_H */
#define CY_PINS_A1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "A1_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    A1_Write(uint8 value) ;
void    A1_SetDriveMode(uint8 mode) ;
uint8   A1_ReadDataReg(void) ;
uint8   A1_Read(void) ;
uint8   A1_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define A1_DRIVE_MODE_BITS        (3)
#define A1_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - A1_DRIVE_MODE_BITS))
#define A1_DRIVE_MODE_SHIFT       (0x00u)
#define A1_DRIVE_MODE_MASK        (0x07u << A1_DRIVE_MODE_SHIFT)

#define A1_DM_ALG_HIZ         (0x00u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_DIG_HIZ         (0x01u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_RES_UP          (0x02u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_RES_DWN         (0x03u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_OD_LO           (0x04u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_OD_HI           (0x05u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_STRONG          (0x06u << A1_DRIVE_MODE_SHIFT)
#define A1_DM_RES_UPDWN       (0x07u << A1_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define A1_MASK               A1__MASK
#define A1_SHIFT              A1__SHIFT
#define A1_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define A1_PS                     (* (reg32 *) A1__PS)
/* Port Configuration */
#define A1_PC                     (* (reg32 *) A1__PC)
/* Data Register */
#define A1_DR                     (* (reg32 *) A1__DR)
/* Input Buffer Disable Override */
#define A1_INP_DIS                (* (reg32 *) A1__PC2)


#if defined(A1__INTSTAT)  /* Interrupt Registers */

    #define A1_INTSTAT                (* (reg32 *) A1__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins A1_H */


/* [] END OF FILE */
