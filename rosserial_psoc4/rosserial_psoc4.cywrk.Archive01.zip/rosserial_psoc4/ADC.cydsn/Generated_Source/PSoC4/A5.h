/*******************************************************************************
* File Name: A5.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_A5_H) /* Pins A5_H */
#define CY_PINS_A5_H

#include "cytypes.h"
#include "cyfitter.h"
#include "A5_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    A5_Write(uint8 value) ;
void    A5_SetDriveMode(uint8 mode) ;
uint8   A5_ReadDataReg(void) ;
uint8   A5_Read(void) ;
uint8   A5_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define A5_DRIVE_MODE_BITS        (3)
#define A5_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - A5_DRIVE_MODE_BITS))
#define A5_DRIVE_MODE_SHIFT       (0x00u)
#define A5_DRIVE_MODE_MASK        (0x07u << A5_DRIVE_MODE_SHIFT)

#define A5_DM_ALG_HIZ         (0x00u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_DIG_HIZ         (0x01u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_RES_UP          (0x02u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_RES_DWN         (0x03u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_OD_LO           (0x04u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_OD_HI           (0x05u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_STRONG          (0x06u << A5_DRIVE_MODE_SHIFT)
#define A5_DM_RES_UPDWN       (0x07u << A5_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define A5_MASK               A5__MASK
#define A5_SHIFT              A5__SHIFT
#define A5_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define A5_PS                     (* (reg32 *) A5__PS)
/* Port Configuration */
#define A5_PC                     (* (reg32 *) A5__PC)
/* Data Register */
#define A5_DR                     (* (reg32 *) A5__DR)
/* Input Buffer Disable Override */
#define A5_INP_DIS                (* (reg32 *) A5__PC2)


#if defined(A5__INTSTAT)  /* Interrupt Registers */

    #define A5_INTSTAT                (* (reg32 *) A5__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins A5_H */


/* [] END OF FILE */
