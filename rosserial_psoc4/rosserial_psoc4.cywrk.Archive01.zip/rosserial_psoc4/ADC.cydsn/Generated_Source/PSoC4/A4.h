/*******************************************************************************
* File Name: A4.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_A4_H) /* Pins A4_H */
#define CY_PINS_A4_H

#include "cytypes.h"
#include "cyfitter.h"
#include "A4_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    A4_Write(uint8 value) ;
void    A4_SetDriveMode(uint8 mode) ;
uint8   A4_ReadDataReg(void) ;
uint8   A4_Read(void) ;
uint8   A4_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define A4_DRIVE_MODE_BITS        (3)
#define A4_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - A4_DRIVE_MODE_BITS))
#define A4_DRIVE_MODE_SHIFT       (0x00u)
#define A4_DRIVE_MODE_MASK        (0x07u << A4_DRIVE_MODE_SHIFT)

#define A4_DM_ALG_HIZ         (0x00u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_DIG_HIZ         (0x01u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_RES_UP          (0x02u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_RES_DWN         (0x03u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_OD_LO           (0x04u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_OD_HI           (0x05u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_STRONG          (0x06u << A4_DRIVE_MODE_SHIFT)
#define A4_DM_RES_UPDWN       (0x07u << A4_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define A4_MASK               A4__MASK
#define A4_SHIFT              A4__SHIFT
#define A4_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define A4_PS                     (* (reg32 *) A4__PS)
/* Port Configuration */
#define A4_PC                     (* (reg32 *) A4__PC)
/* Data Register */
#define A4_DR                     (* (reg32 *) A4__DR)
/* Input Buffer Disable Override */
#define A4_INP_DIS                (* (reg32 *) A4__PC2)


#if defined(A4__INTSTAT)  /* Interrupt Registers */

    #define A4_INTSTAT                (* (reg32 *) A4__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins A4_H */


/* [] END OF FILE */
